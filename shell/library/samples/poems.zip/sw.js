// reader/sw.js -- app shell cache only, this stage. Books are not cached yet
// (that's stage 3, per PROMPTS/reader-pwa.md -- it needs the index + version
// field first; caching book payloads half-built here risks a reader stuck on
// a stale book with no way to tell).
//
// One cache: ttstv-shell-v1 -- reader.html, voiceui/*, manifest, icons,
// probe.html -- filled once, on install, served cache-first. Everything else
// (book.json, timings, audio, dictionary.json, ...) falls straight through
// to the network, not even read from cache, let alone written to it.
//
// Bump SHELL_CACHE's version suffix when the shell file list changes; the
// activate handler deletes every cache that isn't the current shell version,
// so old shell versions are swept and cannot leave two generations mixed.
const SHELL_CACHE = "ttstv-shell-v2";

const SHELL_FILES = [
  "./reader.html",
  "./manifest.webmanifest",
  "./probe.html",
  "./icon-192.png",
  "./icon-512.png",
  "../voiceui/app.js",
  "../voiceui/reader-bridge.js",
  "../voiceui/grammar.js",
  "../voiceui/detour.js",
  "../voiceui/resolve.js",
  "../voiceui/answers.js",
  "../voiceui/tts.js",
  "../voiceui/asr.js",
  "../voiceui/trigger.js",
];

self.addEventListener("install", (event) => {
  event.waitUntil((async () => {
    const cache = await caches.open(SHELL_CACHE);
    // Per-file try/catch, not cache.addAll(): addAll is all-or-nothing, and
    // voiceui/app.js's own require() problem (reader/README.md) or a bundle
    // deployment that never shipped voiceui/* at all must not sink the whole
    // install over one missing file.
    await Promise.all(SHELL_FILES.map(async (url) => {
      try {
        const res = await fetch(url, { cache: "no-store" });
        if (res.ok) await cache.put(url, res);
      } catch (e) {
        console.warn("[sw] shell file not cached:", url, e);
      }
    }));
    self.skipWaiting();
  })());
});

self.addEventListener("activate", (event) => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys
      .filter((k) => k !== SHELL_CACHE)
      .map((k) => caches.delete(k)));
    await self.clients.claim();
  })());
});

self.addEventListener("fetch", (event) => {
  const { request } = event;
  if (request.method !== "GET") return;

  // Navigations (reload, typed URL, "Add to Home Screen" launch) may carry
  // ?left=/&right=/&ch= query params reader.html reads client-side -- match
  // the cached shell HTML by path only, so a reload with a different query
  // string still finds it instead of falling through to the network (which
  // is exactly the case the offline reload test exercises).
  if (request.mode === "navigate") {
    const url = new URL(request.url);
    event.respondWith((async () => {
      const shellCache = await caches.open(SHELL_CACHE);
      const hit = await shellCache.match(url.pathname);
      if (hit) return hit;
      try {
        return await fetch(request);
      } catch (e) {
        return hit || Response.error();
      }
    })());
    return;
  }

  // Everything else: cache-first, but only against the shell cache -- a
  // shell asset (voiceui/*.js, icons, manifest) requested directly rather
  // than via a navigation. Anything not in the shell cache (book.json,
  // timings, audio, dictionary.json, ...) falls straight through to the
  // network, this session -- no book caching yet (see file header).
  event.respondWith((async () => {
    const shellCache = await caches.open(SHELL_CACHE);
    const hit = await shellCache.match(request);
    return hit || fetch(request);
  })());
});
