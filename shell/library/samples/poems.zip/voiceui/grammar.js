// voiceui/grammar.js — tokenise a spoken utterance into an ordered list of
// playback ops. Pure text -> ops; no DOM, no reader, no network. See
// voiceui/README.md "The grammar" for the token vocabulary this implements.
//
// Design note (judgment call, see report): the grammar is COMPOSABLE, not
// positional — "again, slower, ground" and "ground, slower, again" produce
// the identical op list, because the ops are executed in a fixed canonical
// order (SPEED, then SELECT, then BACK/START-AT, then PANE, then the
// transport op, then an auto-POP), not the order the user happened to speak
// them in. That canonical order is exactly what the prompt's own worked
// example requires: "again, slower, ground" -> [speed 0.8, select current
// sentence, pane=ground, play, pop] — "slower" (spoken second) outputs
// before "again" (spoken first).
//
// A bare "ground" or "what" implies its own {op:"play"}: switching to the
// ground pane starts a clock that was not already playing, whereas "again"
// on the pane you're already listening to needs no separate play op. A bare
// "ground"/"what" also implies an automatic trailing {op:"pop"} — per
// voiceui/README.md, ground/what are one-shot detours: "return to L2" is
// automatic, not something the user has to ask for with "continue". An
// explicit "continue" in the same utterance suppresses the auto-pop (the
// user is unwinding the whole detour stack, not just this one level; see
// detour.js applyOps' "continue" vs "pop" handling).
//
// UMD: module.exports under Node (voiceui/tests/*.test.js), or
// window.VoiceUI.grammar in the browser via a plain <script> tag --
// reader.html must stay openable over file://, which Chrome blocks for
// `type="module"` scripts, so this repo has no ES modules and no bundler
// anywhere. See voiceui/README.md "Loading in the browser".
(function (root, factory) {
  "use strict";
  if (typeof module === "object" && module.exports) {
    module.exports = factory();
  } else {
    root.VoiceUI = root.VoiceUI || {};
    root.VoiceUI.grammar = factory();
  }
})(typeof self !== "undefined" ? self : this, function () {
  "use strict";

const SPEED_FASTER_FACTOR = 1.25;
const SPEED_SLOWER_FACTOR = 0.8;

// Execution order is fixed regardless of speech order (see module doc above).
const OP_PRIORITY = { speed: 1, select: 2, back: 3, startAt: 3, pane: 4, transport: 5, pop: 6 };

function splitClauses(text) {
  return text
    .toLowerCase()
    .trim()
    .split(/\s*(?:,|\bthen\b|\band\b)\s*/)
    .map((c) => c.trim())
    .filter(Boolean);
}

function round2(n) {
  return Math.round(n * 100) / 100;
}

// tokenize(utterance) -> Op[]
// Op shapes:
//   {op:"speed", factor:N}   relative multiply (faster/slower, stacks)
//   {op:"speed", set:N}      absolute (normal)
//   {op:"select", target:"current"}
//   {op:"back", amount:N, unit:"words"|"seconds"}
//   {op:"startAt", phrase:string}
//   {op:"pane", value:"ground"|"target"}
//   {op:"play"} | {op:"pause"} | {op:"continue"}
//   {op:"pop"}   auto-appended for a one-shot ground/what detour
function tokenize(utterance) {
  if (typeof utterance !== "string") return [];
  const clauses = splitClauses(utterance);

  let speedFactor = 1;
  let speedSet = null;
  let select = false;
  const backOps = [];
  const startAtOps = [];
  let pane = null;
  let transport = null; // "play" | "pause" | "continue"
  let detourTrigger = false;
  let explicitContinue = false;

  for (const clause of clauses) {
    let m;
    if (/^(again|repeat)$/.test(clause)) {
      select = true;
    } else if (/^faster$/.test(clause)) {
      speedFactor *= SPEED_FASTER_FACTOR;
    } else if (/^slower$/.test(clause)) {
      speedFactor *= SPEED_SLOWER_FACTOR;
    } else if (/^normal( speed)?$/.test(clause)) {
      speedSet = 1;
    } else if (/^(play|start)$/.test(clause)) {
      transport = "play";
    } else if (/^(pause|stop)$/.test(clause)) {
      transport = "pause";
    } else if (/^(continue|resume)$/.test(clause)) {
      transport = "continue";
      explicitContinue = true;
    } else if (/^ground$/.test(clause)) {
      pane = "ground";
      select = true;
      detourTrigger = true;
      if (!transport) transport = "play";
    } else if (/^target$/.test(clause)) {
      pane = "target";
    } else if (/^what$/.test(clause)) {
      select = true;
      pane = "ground";
      detourTrigger = true;
      transport = "play";
    } else if ((m = clause.match(/^back (\d+) (words?|seconds?)$/))) {
      backOps.push({ amount: parseInt(m[1], 10), unit: m[2].startsWith("word") ? "words" : "seconds" });
    } else if ((m = clause.match(/^start at (.+)$/))) {
      startAtOps.push(m[1].trim());
    }
    // Anything else is not this grammar's vocabulary -- left unrecognised
    // rather than guessed at. A language-tool query ("what does X mean")
    // is parsed separately; see resolve.js/answers.js and app.js.
  }

  const ops = [];
  if (speedSet !== null) ops.push({ op: "speed", set: speedSet });
  else if (speedFactor !== 1) ops.push({ op: "speed", factor: round2(speedFactor) });
  if (select) ops.push({ op: "select", target: "current" });
  for (const b of backOps) ops.push({ op: "back", amount: b.amount, unit: b.unit });
  for (const phrase of startAtOps) ops.push({ op: "startAt", phrase });
  if (pane) ops.push({ op: "pane", value: pane });
  if (transport) ops.push({ op: transport });
  if (detourTrigger && !explicitContinue) ops.push({ op: "pop" });

  return ops;
}

  return { tokenize, OP_PRIORITY, SPEED_FASTER_FACTOR, SPEED_SLOWER_FACTOR };
});
