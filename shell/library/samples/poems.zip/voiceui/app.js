// voiceui/app.js -- orchestrates grammar -> detour -> reader-bridge for
// playback commands, and resolve -> answers -> tts for language-tool
// queries ("what does X mean", "what form is X", ...). This is the
// TTS_TV_Hands_Free_Voice_Layer.md "intent router" + "context resolver" in
// one small module.
//
// Fully testable without a browser or reader/: give createVoiceUI() a fake
// bridge (voiceui/reader-bridge.js's REQUIRED_METHODS shape), a fake synth
// (tts.createFakeSynth()), and plain-object sentence/dictionary lookups
// backed by real book.json/dictionary.json fixtures read with `fs`. There is
// no real reader.html or browser wired up yet -- see this module's README
// entry for exactly what's missing and why.
//
// UMD: module.exports under Node (requires its sibling voiceui/*.js files
// directly), or window.VoiceUI.app in the browser via a plain <script> tag
// loaded AFTER grammar.js/detour.js/resolve.js/answers.js/tts.js have each
// attached themselves to window.VoiceUI -- see grammar.js's file header for
// why there's no ES modules/bundler, and voiceui/README.md "Loading in the
// browser" for the required <script> order.
(function (root, factory) {
  "use strict";
  if (typeof module === "object" && module.exports) {
    module.exports = factory(
      require("./grammar"),
      require("./detour"),
      require("./resolve"),
      require("./answers"),
      require("./tts")
    );
  } else {
    root.VoiceUI = root.VoiceUI || {};
    root.VoiceUI.app = factory(
      root.VoiceUI.grammar,
      root.VoiceUI.detour,
      root.VoiceUI.resolve,
      root.VoiceUI.answers,
      root.VoiceUI.tts
    );
  }
})(typeof self !== "undefined" ? self : this, function (grammar, detourModule, resolve, answers, tts) {
  "use strict";
  const { DetourStack } = detourModule;

// "what does X mean" / "what form is X" / "why is this dative" / "what's
// the conjugation here" -- voiceui/README.md "Language tools by voice".
// A null `word` means the query didn't name one; app.js falls back to
// whatever word the reader currently has highlighted (bridge.getPosition's
// wordId), per TTS_TV_Hands_Free_Voice_Layer.md's context-resolver idea:
// "the system should infer the relevant context automatically."
// Order matters: "what does this mean" must be checked before the general
// "what does X mean" pattern, or (.+) greedily captures "this" as if it were
// a named word instead of the no-word-named case.
const LOOKUP_PATTERNS = [
  { re: /^what does this mean$/, word: () => null },
  { re: /^what does (.+) mean$/, word: (m) => m[1] },
  { re: /^what form is (.+)$/, word: (m) => m[1] },
  { re: /^why is this (.+)$/, word: () => null },
  { re: /^what'?s the conjugation( here)?$/, word: () => null },
];

function parseLookupQuery(text) {
  const t = text.toLowerCase().trim().replace(/[.?!]+$/, "");
  for (const { re, word } of LOOKUP_PATTERNS) {
    const m = t.match(re);
    if (m) return { word: word(m) };
  }
  return null;
}

// Drives the reader-bridge for one utterance's ops. `side` starts as
// whichever pane the user is actually listening to ("target" by
// convention -- README: the user is normally listening to L2). A
// {op:"pane", value:"ground"} pushes the pre-switch position onto `detour`
// and resolves the aligned sentence on the ground side; the immediately
// following {op:"play"} then means "play that aligned segment and wait for
// it to end" (bridge.playAlignedSegment's promise) rather than a bare
// bridge.play(side) -- that's the one place this function treats two ops as
// a single composite action. See grammar.js's module doc for why "pop"
// always follows in the same ops list for a bare ground/what utterance.
async function runOps(ops, { bridge, side, detour }) {
  let currentSide = side;
  let enteringDetour = null; // {fromSide, sentenceId} set by the pane op just processed

  for (const op of ops) {
    switch (op.op) {
      case "speed": {
        const cur = bridge.getSpeed(currentSide);
        bridge.setSpeed(currentSide, op.set !== undefined ? op.set : cur * op.factor);
        break;
      }
      case "select":
        bridge.seekSentenceDelta(currentSide, 0);
        break;
      case "back":
        if (op.unit === "words") bridge.seekWordDelta(currentSide, -op.amount);
        else bridge.seekSeconds(currentSide, -op.amount);
        break;
      case "startAt":
        // No reader hook for phrase search yet -- documented gap, see README.
        break;
      case "pane": {
        if (op.value === "ground" && currentSide !== "ground") {
          const pos = bridge.getPosition(currentSide);
          detour.push({ side: currentSide, position: pos });
          const alignedId = pos ? bridge.getAlignedSentenceId(currentSide, pos.sentenceId) : null;
          enteringDetour = { fromSide: currentSide, sentenceId: alignedId };
          currentSide = "ground";
        } else if (op.value === "target") {
          currentSide = "target";
        }
        break;
      }
      case "play":
        if (enteringDetour) {
          await bridge.playAlignedSegment(enteringDetour.fromSide, enteringDetour.sentenceId);
          enteringDetour = null;
        } else {
          bridge.play(currentSide);
        }
        break;
      case "pause":
        bridge.pause(currentSide);
        break;
      case "continue": {
        const base = detour.popToBase();
        if (base) currentSide = base.side;
        bridge.play(currentSide);
        break;
      }
      case "pop": {
        const frame = detour.pop();
        if (frame) currentSide = frame.side;
        bridge.play(currentSide);
        break;
      }
      default:
        break;
    }
  }
  return currentSide;
}

function createVoiceUI({ bridge, getSentenceWords, getPreviousSentenceId, getDictionaryEntry, synth }) {
  const detour = new DetourStack();
  let side = "target";

  async function answerLookup(query) {
    const pos = bridge.getPosition(side);
    if (!pos) return { type: "answer", text: "Nothing is playing yet." };

    let wordId = pos.wordId;
    let surfaceText = null;

    if (query.word) {
      const current = getSentenceWords(side, pos.sentenceId) || [];
      const prevId = getPreviousSentenceId(side, pos.sentenceId);
      const previous = prevId ? getSentenceWords(side, prevId) || [] : [];
      const match = resolve.resolveWord(query.word, current, previous);
      if (!match) {
        const text = "Which word?";
        await tts.speak(text, { synth });
        return { type: "answer", text, clarify: true };
      }
      wordId = match.id;
      surfaceText = match.text;
    } else {
      const current = getSentenceWords(side, pos.sentenceId) || [];
      const w = current.find((x) => x.id === wordId);
      surfaceText = w ? w.text : null;
    }

    if (!surfaceText) {
      const text = "Which word?";
      await tts.speak(text, { synth });
      return { type: "answer", text, clarify: true };
    }

    const entry = getDictionaryEntry(side, surfaceText);
    const text = answers.formatAnswer(entry, surfaceText);
    await tts.speak(text, { synth });
    return { type: "answer", text, wordId };
  }

  async function handleUtterance(text) {
    const query = parseLookupQuery(text);
    if (query) return answerLookup(query);

    const ops = grammar.tokenize(text);
    if (!ops.length) return { type: "unrecognized", text };

    side = await runOps(ops, { bridge, side, detour });
    return { type: "ops", ops, side };
  }

  return { handleUtterance, _detour: detour };
}

  return { createVoiceUI, parseLookupQuery, runOps };
});
