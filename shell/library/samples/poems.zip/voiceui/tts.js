// voiceui/tts.js -- speechSynthesis wrapper for the short spoken answers
// (voiceui/README.md: "Speech out: speechSynthesis for the short template
// answers; a different voice from the narrator, deliberately."). Answers are
// produced by answers.js as a single sentence; this module's only job is to
// speak one string and resolve when it finishes.
//
// UMD: module.exports under Node, or window.VoiceUI.tts in the browser via
// a plain <script> tag -- see grammar.js's file header for why (no ES
// modules, no bundler; reader.html must stay file://-capable).
(function (root, factory) {
  "use strict";
  if (typeof module === "object" && module.exports) {
    module.exports = factory();
  } else {
    root.VoiceUI = root.VoiceUI || {};
    root.VoiceUI.tts = factory();
  }
})(typeof self !== "undefined" ? self : this, function () {
  "use strict";

function speak(text, { synth, rate = 1, voiceName = null } = {}) {
  if (!synth || typeof synth.speak !== "function") {
    throw new Error(
      "speak() requires opts.synth -- window.speechSynthesis in the browser, or tts.createFakeSynth() in tests."
    );
  }
  const hasRealUtterance = typeof SpeechSynthesisUtterance !== "undefined";
  const utterance = hasRealUtterance ? new SpeechSynthesisUtterance(text) : { text };
  utterance.rate = rate;
  if (voiceName && typeof synth.getVoices === "function") {
    const match = synth.getVoices().find((v) => v.name === voiceName);
    if (match) utterance.voice = match;
  }
  return new Promise((resolve, reject) => {
    utterance.onend = () => resolve();
    utterance.onerror = (e) => reject(e);
    synth.speak(utterance);
  });
}

// A minimal stand-in for window.speechSynthesis. speak() resolves the
// utterance synchronously (records the text spoken, calls onend) -- no
// audio, no timers, so tests stay fast and deterministic.
function createFakeSynth() {
  return {
    spoken: [],
    speak(utterance) {
      this.spoken.push(utterance.text);
      if (utterance.onend) utterance.onend();
    },
    cancel() {
      this.spoken.length = 0;
    },
    getVoices() {
      return [];
    },
  };
}

  return { speak, createFakeSynth };
});
